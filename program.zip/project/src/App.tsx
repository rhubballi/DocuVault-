import React, { useState } from 'react';
import { Briefcase } from 'lucide-react';
import SecurityVerification from './components/SecurityVerification';
import FileUpload from './components/FileUpload';
import FileSearch from './components/FileSearch';
import FileList from './components/FileList';
import { useFiles } from './hooks/useFiles';

function App() {
  const [isVerified, setIsVerified] = useState(false);
  const [activeTab, setActiveTab] = useState<'upload' | 'search'>('upload');
  const { files, searchResults, handleFileUpload, handleSearch } = useFiles();

  if (!isVerified) {
    return (
      <div className="min-h-screen animate-gradient py-12 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8 slide-in">
            <div className="animate-float">
              <Briefcase className="w-20 h-20 text-white mx-auto mb-4" />
            </div>
            <h1 className="text-5xl font-bold text-white mb-2">
              DocuVault Pro
            </h1>
            <p className="text-white/90 text-xl">
              Enterprise Document Management Solution
            </p>
          </div>
          <SecurityVerification onVerificationSuccess={() => setIsVerified(true)} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen animate-gradient py-12 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8 slide-in">
          <div className="animate-float">
            <Briefcase className="w-16 h-16 text-white mx-auto mb-4" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">
            DocuVault Pro
          </h1>
          <p className="text-white/90">
            Secure Document Management Made Simple
          </p>
        </div>

        <div className="flex justify-center mb-8 slide-in" style={{animationDelay: '0.2s'}}>
          <div className="inline-flex rounded-full p-1 bg-white/20 backdrop-blur-sm">
            <button
              onClick={() => setActiveTab('upload')}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                activeTab === 'upload'
                  ? 'bg-white text-blue-600 shadow-lg'
                  : 'text-white hover:bg-white/10'
              }`}
            >
              Upload
            </button>
            <button
              onClick={() => setActiveTab('search')}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
                activeTab === 'search'
                  ? 'bg-white text-blue-600 shadow-lg'
                  : 'text-white hover:bg-white/10'
              }`}
            >
              Search
            </button>
          </div>
        </div>

        <div className="slide-in" style={{animationDelay: '0.3s'}}>
          {activeTab === 'upload' ? (
            <FileUpload onFileUpload={handleFileUpload} />
          ) : (
            <FileSearch onSearch={handleSearch} />
          )}
        </div>

        <div className="slide-in" style={{animationDelay: '0.4s'}}>
          <FileList files={files} searchResults={searchResults} />
        </div>
      </div>
    </div>
  );
}

export default App;