import React, { useState } from 'react';
import { Search, FileType } from 'lucide-react';

interface FileSearchProps {
  onSearch: (criteria: SearchCriteria) => void;
}

interface SearchCriteria {
  fileType: string;
  category: string;
  department: string;
  daysOld: string;
}

const FileSearch: React.FC<FileSearchProps> = ({ onSearch }) => {
  const [criteria, setCriteria] = useState<SearchCriteria>({
    fileType: '',
    category: '',
    department: '',
    daysOld: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(criteria);
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-lg">
      <div className="flex items-center justify-center mb-6">
        <Search className="w-8 h-8 text-blue-600 mr-2" />
        <h2 className="text-2xl font-bold text-gray-800">Search Documents</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-gray-700 font-medium mb-2">
            File Type
          </label>
          <select
            value={criteria.fileType}
            onChange={(e) => setCriteria({ ...criteria, fileType: e.target.value })}
            className="w-full p-2 border border-gray-300 rounded-md"
          >
            <option value="">Select Type</option>
            <option value="PDF">PDF</option>
            <option value="Document">Document</option>
            <option value="Image">Image</option>
            <option value="Spreadsheet">Spreadsheet</option>
          </select>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Category
          </label>
          <select
            value={criteria.category}
            onChange={(e) => setCriteria({ ...criteria, category: e.target.value })}
            className="w-full p-2 border border-gray-300 rounded-md"
          >
            <option value="">Select Category</option>
            <option value="HR">HR</option>
            <option value="Finance">Finance</option>
            <option value="Legal">Legal</option>
            <option value="Operations">Operations</option>
          </select>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Department
          </label>
          <select
            value={criteria.department}
            onChange={(e) => setCriteria({ ...criteria, department: e.target.value })}
            className="w-full p-2 border border-gray-300 rounded-md"
          >
            <option value="">Select Department</option>
            <option value="Management">Management</option>
            <option value="Development">Development</option>
            <option value="Marketing">Marketing</option>
            <option value="Sales">Sales</option>
          </select>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Days Old
          </label>
          <input
            type="number"
            value={criteria.daysOld}
            onChange={(e) => setCriteria({ ...criteria, daysOld: e.target.value })}
            className="w-full p-2 border border-gray-300 rounded-md"
            min="0"
          />
        </div>

        <div className="flex space-x-4">
          <button
            type="submit"
            className="flex-1 bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition duration-200"
          >
            Search
          </button>
          <button
            type="button"
            onClick={() => setCriteria({ fileType: '', category: '', department: '', daysOld: '' })}
            className="flex-1 bg-gray-500 text-white py-2 px-4 rounded-md hover:bg-gray-600 transition duration-200"
          >
            Reset
          </button>
        </div>
      </form>
    </div>
  );
};

export default FileSearch;