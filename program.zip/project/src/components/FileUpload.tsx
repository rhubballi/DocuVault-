import React, { useState } from 'react';
import { Upload, Calendar, FileType } from 'lucide-react';

interface FileData {
  id: string;
  name: string;
  type: string;
  category: string;
  department: string;
  daysOld: number;
  url: string;
}

interface FileUploadProps {
  onFileUpload: (fileData: FileData) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileUpload }) => {
  const [file, setFile] = useState<File | null>(null);
  const [fileType, setFileType] = useState('');
  const [category, setCategory] = useState('');
  const [department, setDepartment] = useState('');
  const [daysOld, setDaysOld] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (file) {
      const fileData: FileData = {
        id: Date.now().toString(),
        name: file.name,
        type: fileType,
        category,
        department,
        daysOld: parseInt(daysOld),
        url: URL.createObjectURL(file)
      };
      onFileUpload(fileData);
      
      // Reset form
      setFile(null);
      setFileType('');
      setCategory('');
      setDepartment('');
      setDaysOld('');
      
      // Reset file input
      const fileInput = document.getElementById('fileInput') as HTMLInputElement;
      if (fileInput) fileInput.value = '';
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-lg">
      <div className="flex items-center justify-center mb-6">
        <Upload className="w-8 h-8 text-blue-600 mr-2" />
        <h2 className="text-2xl font-bold text-gray-800">Upload Document</h2>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Select File
          </label>
          <input
            id="fileInput"
            type="file"
            onChange={(e) => setFile(e.target.files?.[0] || null)}
            className="w-full p-2 border border-gray-300 rounded-md"
            required
          />
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">
            File Type
          </label>
          <select
            value={fileType}
            onChange={(e) => setFileType(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md"
            required
          >
            <option value="">Select Type</option>
            <option value="PDF">PDF</option>
            <option value="Document">Document</option>
            <option value="Image">Image</option>
            <option value="Spreadsheet">Spreadsheet</option>
          </select>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Category
          </label>
          <select
            value={category}
            onChange={(e) => setCategory(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md"
            required
          >
            <option value="">Select Category</option>
            <option value="HR">HR</option>
            <option value="Finance">Finance</option>
            <option value="Legal">Legal</option>
            <option value="Operations">Operations</option>
          </select>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Department
          </label>
          <select
            value={department}
            onChange={(e) => setDepartment(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md"
            required
          >
            <option value="">Select Department</option>
            <option value="Management">Management</option>
            <option value="Development">Development</option>
            <option value="Marketing">Marketing</option>
            <option value="Sales">Sales</option>
          </select>
        </div>

        <div>
          <label className="block text-gray-700 font-medium mb-2">
            Days Old
          </label>
          <input
            type="number"
            value={daysOld}
            onChange={(e) => setDaysOld(e.target.value)}
            className="w-full p-2 border border-gray-300 rounded-md"
            min="0"
            required
          />
        </div>

        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition duration-200"
        >
          Upload Document
        </button>
      </form>
    </div>
  );
};

export default FileUpload;