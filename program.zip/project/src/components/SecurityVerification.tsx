import React, { useState } from 'react';
import { ShieldCheck } from 'lucide-react';

const securityQuestions = [
  {
    question: "Select the correct access level for this system:",
    options: ["Public Access", "Employee Access", "Guest Access", "Restricted Access"],
    correct: "Employee Access"
  },
  {
    question: "Choose the correct way to handle confidential documents:",
    options: ["Share Freely", "Store Securely", "Email to Everyone", "Print Copies"],
    correct: "Store Securely"
  },
  {
    question: "What is required to access this system?",
    options: ["Social Media Account", "Company Credentials", "Public Link", "None"],
    correct: "Company Credentials"
  }
];

interface SecurityVerificationProps {
  onVerificationSuccess: () => void;
}

const SecurityVerification: React.FC<SecurityVerificationProps> = ({ onVerificationSuccess }) => {
  const [answers, setAnswers] = useState<string[]>(Array(securityQuestions.length).fill(''));
  const [error, setError] = useState('');
  const [showHint, setShowHint] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const isCorrect = answers.every((answer, index) => 
      answer === securityQuestions[index].correct
    );

    if (isCorrect) {
      onVerificationSuccess();
      setError('');
      setShowHint(false);
    } else {
      setError('Please review your answers and try again.');
      setShowHint(true);
    }
  };

  return (
    <div className="max-w-md mx-auto p-6 bg-white rounded-lg shadow-lg">
      <div className="flex items-center justify-center mb-6">
        <ShieldCheck className="w-8 h-8 text-blue-600 mr-2" />
        <h2 className="text-2xl font-bold text-gray-800">Security Check</h2>
      </div>
      
      <div className="mb-4 text-center">
        <p className="text-gray-600">Please answer these security questions to access the system</p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {securityQuestions.map((q, index) => (
          <div key={index} className="mb-4">
            <label className="block text-gray-700 font-medium mb-2">
              {q.question}
            </label>
            <select
              value={answers[index]}
              onChange={(e) => {
                const newAnswers = [...answers];
                newAnswers[index] = e.target.value;
                setAnswers(newAnswers);
                setError('');
                setShowHint(false);
              }}
              className="w-full p-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              required
            >
              <option value="">Select your answer</option>
              {q.options.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
          </div>
        ))}
        
        {error && (
          <div className="text-center">
            <p className="text-red-500 mb-2">{error}</p>
            {showHint && (
              <p className="text-gray-600 text-sm">
                Hint: Think about standard company security practices
              </p>
            )}
          </div>
        )}
        
        <button
          type="submit"
          className="w-full bg-blue-600 text-white py-3 px-4 rounded-md hover:bg-blue-700 transition duration-200 font-medium"
        >
          Verify & Continue
        </button>
      </form>
    </div>
  );
};

export default SecurityVerification;