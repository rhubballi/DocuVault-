import React from 'react';
import { FileText, Download } from 'lucide-react';

interface FileData {
  id: string;
  name: string;
  type: string;
  category: string;
  department: string;
  daysOld: number;
  url: string;
}

interface FileListProps {
  files: FileData[];
  searchResults: FileData[] | null;
}

const FileList: React.FC<FileListProps> = ({ files, searchResults }) => {
  const displayFiles = searchResults || files;

  if (displayFiles.length === 0) {
    return (
      <div className="text-center text-gray-500 mt-8">
        No files found
      </div>
    );
  }

  return (
    <div className="mt-8">
      <h3 className="text-xl font-bold mb-4">
        {searchResults ? 'Search Results' : 'Recent Files'}
      </h3>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {displayFiles.map((file) => (
          <div
            key={file.id}
            className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition duration-200"
          >
            <div className="flex items-center justify-between mb-2">
              <FileText className="w-8 h-8 text-blue-600" />
              <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded-full text-sm">
                {file.type}
              </span>
            </div>
            <h4 className="font-semibold text-gray-800 mb-2">{file.name}</h4>
            <div className="text-sm text-gray-600 space-y-1">
              <p>Category: {file.category}</p>
              <p>Department: {file.department}</p>
              <p>Days Old: {file.daysOld}</p>
            </div>
            <a
              href={file.url}
              download={file.name}
              className="mt-4 inline-flex items-center text-blue-600 hover:text-blue-800"
            >
              <Download className="w-4 h-4 mr-1" />
              Download
            </a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default FileList;