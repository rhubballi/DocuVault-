import { useState, useEffect } from 'react';
import { FileData, loadFiles, saveFiles, addFile } from '../utils/storage';

export const useFiles = () => {
  const [files, setFiles] = useState<FileData[]>([]);
  const [searchResults, setSearchResults] = useState<FileData[] | null>(null);

  useEffect(() => {
    const savedFiles = loadFiles();
    setFiles(savedFiles);
  }, []);

  const handleFileUpload = (fileData: FileData) => {
    const updatedFiles = addFile(fileData);
    setFiles(updatedFiles);
    setSearchResults(null);
  };

  const handleSearch = (criteria: {
    fileType: string;
    category: string;
    department: string;
    daysOld: string;
  }) => {
    const results = files.filter(file => {
      return (
        (!criteria.fileType || file.type === criteria.fileType) &&
        (!criteria.category || file.category === criteria.category) &&
        (!criteria.department || file.department === criteria.department) &&
        (!criteria.daysOld || file.daysOld <= parseInt(criteria.daysOld))
      );
    });
    setSearchResults(results);
  };

  return {
    files,
    searchResults,
    handleFileUpload,
    handleSearch,
  };
};