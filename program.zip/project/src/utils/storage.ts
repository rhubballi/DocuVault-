export interface FileData {
  id: string;
  name: string;
  type: string;
  category: string;
  department: string;
  daysOld: number;
  url: string;
}

export const saveFiles = (files: FileData[]): void => {
  localStorage.setItem('documentFiles', JSON.stringify(files));
};

export const loadFiles = (): FileData[] => {
  const savedFiles = localStorage.getItem('documentFiles');
  return savedFiles ? JSON.parse(savedFiles) : [];
};

export const addFile = (file: FileData): FileData[] => {
  const currentFiles = loadFiles();
  const updatedFiles = [file, ...currentFiles];
  saveFiles(updatedFiles);
  return updatedFiles;
};